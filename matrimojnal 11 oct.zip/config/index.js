const connectToDatabase = require('./db');

module.exports = {
  connectToDatabase,
};
