// models/Favorite.js
const mongoose = require('mongoose');

const favoritesSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },
    itemType: { type: String, required: true, enum: ['Book', 'Dhyaan'] },
    itemId: { type: mongoose.Schema.Types.ObjectId, required: true, refPath: 'itemType' },
    addedAt: { type: Date, default: Date.now }
  },
  {
    timestamps: {
      createdAt: 'created_at',
      updatedAt: 'updated_at',
    },
    collection: 'favorites',
  }
);

const Favorite = mongoose.model('Favorite', favoritesSchema);
module.exports = Favorite;
