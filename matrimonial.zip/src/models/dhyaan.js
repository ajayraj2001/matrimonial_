const mongoose = require('mongoose');

const dhyaanSchema = new mongoose.Schema(
  {
    dhyanName: { type: String, trim: true, required: true },
    dhyanDescription: { type: String, trim: true, default:"" },
    dhyanPoster: { type: String, deault: "" }, // This will store the path of the uploaded poster image
    dhyanContent: { type: String, required: true },
    isActive: { type: Boolean, default: true },
    addedToHome: { type: Boolean, default: false },
    clicks:{type: Number, default: 0},
    rating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    priority: {
      type: Number,
      min: 1,
      max: 10,
      default: null, // Allows for documents without priority
    }
  },
  {
    timestamps: {
      createdAt: 'created_at',
      updatedAt: 'updated_at',
    },
    collection: 'dhyaans',
  }
);

const Dhyaan = mongoose.model('Dhyaan', dhyaanSchema);
module.exports = Dhyaan;
