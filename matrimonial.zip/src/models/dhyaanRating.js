const mongoose = require('mongoose');

const RatingSchema = new mongoose.Schema({
  dhyaan: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Dhyaan', 
    required: true 
  },
  user: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  rating: { 
    type: Number, 
    required: true, 
    min: 1, 
    max: 5 
  }
}, { timestamps: true });

RatingSchema.index({ book: 1, user: 1 }, { unique: true }); // Ensure a user can only rate a book once

const DhyaanRating = mongoose.model('DhyaanRating', RatingSchema);

module.exports = DhyaanRating;
