const Admin = require("./admin");
const Book = require("./book");
const Dhyaan = require("./dhyaan");
const AppData = require("./appData");
const User = require("./user");

const Favorite = require('./favorite')
const BookRating = require('./bookRating')
const DhyaanRating = require('./dhyaanRating')
const Tag = require('./tag')
const RecentSearch = require('./recentSearch')

module.exports = {
  Admin,
  Book,
  Dhyaan,
  User,
  AppData,
  Favorite,
  BookRating,
  DhyaanRating,
  Tag,
  RecentSearch,
};
