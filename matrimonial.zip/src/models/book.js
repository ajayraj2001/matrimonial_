const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema(
  {
    bookName: { type: String, trim: true, required: true },
    bookDescription: { type: String, trim: true, default: "" },
    coverImage: { type: String, default: "" }, // Path to the cover image
    pdfUrl: { type: String, default: null }, // Path to the PDF file
    isActive: { type: Boolean, default: true },
    addedToHome: { type: Boolean, default: false }, // Indicates if the book is added to the homepage
    clicks:{type: Number, default: 0},
    rating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    priority: {
      type: Number,
      min: 1,
      max: 10,
      default: null, // Allows for documents without priority
    }
  },
  {
    timestamps: {
      createdAt: 'created_at',
      updatedAt: 'updated_at',
    },
    collection: 'books',
  }
);

const Book = mongoose.model('Book', bookSchema);
module.exports = Book;
