const authenticateUser = require("../middlewares/authenticateUser");
const bodyParser = require("body-parser");

const {signup, verifyOtpSignUp, login, verifyOtpLogin, forgotPassword, resetPassword} = require("../controllers/user/authController");
const {getProfile, updateProfile, deleteProfileImage} = require("../controllers/user/profileController");

const userRoute = require("express").Router();

//---------- user auth ----------
userRoute.post("/signup", signup);
userRoute.post("/verify_otp_sign_up", verifyOtpSignUp);
userRoute.post("/login", login);
userRoute.post("/verify_otp_login", verifyOtpLogin);
userRoute.post("/forget_password", forgotPassword);
userRoute.post("/reset_password", resetPassword);

userRoute.get("/profile", authenticateUser, getProfile);
userRoute.put("/profile", authenticateUser, updateProfile);
userRoute.post("/deleteProfileImage", authenticateUser, deleteProfileImage);
// userRoute.post('/logout', authenticateUser, logout)

// userRoute.get("/dashboard", authenticateUser, userDashboard);
// //-----------------books-------------------
// userRoute.get("/all_books", authenticateUser, getAllBooks);
// userRoute.get("/book/:id", authenticateUser, getBookById);
// userRoute.post("/rate_book/:id", authenticateUser, rateBook);

// //----------------dhyaan------------------------
// userRoute.get("/all_dhyaans", authenticateUser, getAllDhyaans);
// userRoute.get("/dhyaan/:id", authenticateUser, getDhyaanById);
// userRoute.post("/rate_dhyaan/:id", authenticateUser, rateDhyaan);

// //---------- appData ----------
// userRoute.get("/AllAppData", authenticateUser, getAllAppData);
// userRoute.get("/appData/:key", authenticateUser, getAppData);

// //---------- favourites --------
// userRoute.post("/favorites", authenticateUser, addFavourite);
// userRoute.delete("/favorites", authenticateUser, removeFromFavorites);
// userRoute.get("/favorites", authenticateUser, getFavorites);
// userRoute.get("/checkFavorite", authenticateUser, checkFavoriteStatus)

// //---------------tags-------------
// userRoute.get("/tags", authenticateUser, getTags)

module.exports = userRoute;
