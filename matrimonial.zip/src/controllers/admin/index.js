const getProfile = require("./auth/getProfile");
const login = require("./auth/login");
const forgetPassword = require("./auth/forgetPassword");
const updateProfile = require("./auth/updateProfile");
const verifyOtp = require("./auth/verifyOtp");
const resetPassword = require("./auth/resetPassword");
const changePassword = require("./auth/changePassword");

const adminDashboard = require("./dasboard/adminDashboard")

const createBook = require("./book/createBook");
const {getBookById, getAllBooks } = require("./book/getBooks");
const getPriorityBooks = require("./book/getpriorityBooks");
const updateBookById = require("./book/updateBook");
const deleteBookById = require("./book/deleteBook");

const createDhyaan = require("./dhyaan/createDhyaan");
const { getDhyaanById, getAllDhyaans} = require("./dhyaan/getDhyaan");
const getPriorityDhyaan = require("./dhyaan/getpriorityDhyaan");
const updateDhyaan = require("./dhyaan/updateDhyaan");
const deleteDhyaan = require("./dhyaan/deleteDhyaan");

const createAppData = require("./appData/createAppData")
const getAllAppData = require("./appData/getAppData")
const updateAppData = require("./appData/updateAppData")
const deleteAppData = require("./appData/deleteAppData")

const setPriorityToNull = require("./setPriorityNull/setPriorityNull")

const getUsers = require("./getUsers/getUsers")
const updateUser = require("./getUsers/updateUser")

const createTag = require("./tags/createTag")
const getTags = require("./tags/getTags")
const updateTag = require("./tags/updateTag")
const deleteTag = require("./tags/deleteTag")

//reviews
const approveReviews = require('./review/updateReview')
const getReviews = require('./review/getReview')


module.exports = {

  //auth
  login,
  forgetPassword,
  verifyOtp,
  resetPassword,
  getProfile,
  updateProfile,
  changePassword,

  //dashboard
  adminDashboard,

  //book
  createBook,
  getBookById, getAllBooks,
  getPriorityBooks,
  updateBookById,
  deleteBookById,

  //dhyaan
  createDhyaan,
   getDhyaanById, getAllDhyaans,
   getPriorityDhyaan,
   updateDhyaan,
   deleteDhyaan,


   setPriorityToNull,

  //getUsers
  getUsers,
  updateUser,

  //appData
  createAppData,
  getAllAppData,
  updateAppData,
  deleteAppData,

  //tags
  createTag,
  getTags,
  updateTag,
  deleteTag,

};
