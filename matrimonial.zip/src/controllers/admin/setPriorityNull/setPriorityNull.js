const { Book, Dhyaan } = require('../../../models'); // Adjust the path according to your project structure

// Set priority to null by ID based on type
const setPriorityToNull = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { type } = req.body;

    let updatedDocument;
    let message;

    if (type === 'dhyaan') {
      // Find the Dhyaan by ID and update its priority to null
      updatedDocument = await Dhyaan.findByIdAndUpdate(
        id,
        { priority: null },
        { new: true } // Return the updated document
      );

      message = 'Priority removed from Dhyaan successfully';
    } else if (type === 'book') {
      // Find the Book by ID and update its priority to null
      updatedDocument = await Book.findByIdAndUpdate(
        id,
        { priority: null },
        { new: true } // Return the updated document
      );

      message = 'Priority removed from Book successfully';
    } else {
      return res.status(400).json({
        success: false,
        message: 'Invalid type provided. Please specify either "book" or "dhyaan".',
      });
    }

    if (!updatedDocument) {
      return res.status(404).json({
        success: false,
        message: `${type.charAt(0).toUpperCase() + type.slice(1)} not found`,
      });
    }

    return res.status(200).json({
      success: true,
      message: message,
      data: updatedDocument,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = setPriorityToNull;
