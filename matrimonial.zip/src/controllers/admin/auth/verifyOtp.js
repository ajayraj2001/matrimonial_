const { ApiError } = require('../../../errorHandler');
const { Admin } = require('../../../models');

const verifyOtp = async (req, res, next) => {
  try {
    const { email, otp } = req.body;

    // Validate input
    if (!email || !otp) throw new ApiError('Email and OTP are required', 400);

    // Find the admin by phone or email
    const admin = await Admin.findOne({ email:email});
    if (!admin) throw new ApiError('Admin not found', 404);

    // Validate OTP
    if (Date.now() > new Date(admin.otp_expiry).getTime()) throw new ApiError('OTP expired', 400);
    if (admin.otp !== otp) throw new ApiError('Invalid OTP', 400);

    // If OTP is valid, return success response
    return res.status(200).json({
      success: true,
      message: 'OTP verified successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = verifyOtp;
