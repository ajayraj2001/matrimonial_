const { Admin } = require('../../../models');

const getProfile = async (req, res, next) => {
  try {
    // Find the admin by their ID
    const admin = await Admin.findById(req.admin._id);

    // If admin is not found, return an error
    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found',
      });
    }

    // Return the admin's profile
    return res.status(200).json({
      success: true,
      message: 'Admin Profile',
      user: admin
    });
  } catch (error) {
    next(error);
  }
};

module.exports = getProfile;

