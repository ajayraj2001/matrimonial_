const { ApiError } = require('../../../errorHandler');
const { Admin } = require('../../../models');
const { getOtp } = require('../../../utils');
const sendOtpEmail = require('../../../utils/sendOtpToEmail'); // Import the Nodemailer function

const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) throw new ApiError('Email is required', 400);

    // Find the admin by either phone or email
    // const admin = await Admin.findOne({
    //   $or: [{ phone: phone_or_email }, { email: phone_or_email }],
    // });

     const admin = await Admin.findOne({email: email});
    
    if (!admin) throw new ApiError('Admin not found with this email', 404);

    const otp = getOtp();
    const otpExpiry = new Date(Date.now() + 2 * 60 * 1000);

    admin.otp = otp;
    admin.otp_expiry = otpExpiry;
    await admin.save();

    // Send OTP via email using Nodemailer
    await sendOtpEmail(admin.email, otp);

    return res.status(200).json({
      success: true,
      message: `OTP has been sent to your registered email ${admin.email}`
    });
  } catch (error) {
    next(error);
  }
};

module.exports = forgotPassword;
