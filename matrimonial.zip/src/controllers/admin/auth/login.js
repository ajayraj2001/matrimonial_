const { ApiError } = require('../../../errorHandler');
const { Admin } = require('../../../models');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { ACCESS_TOKEN_SECRET } = process.env;

const login = async (req, res, next) => {
  try {
    let { email, password } = req.body;
    if (!email) throw new ApiError('Email is Required', 403);

    if (!password) throw new ApiError('Password is Required', 403);

    // const admin = await Admin.findOne({ $or: [{ phone: phone_or_email }, { email: phone_or_email }] });
    const admin = await Admin.findOne({ email: email });
    if (!admin) throw new ApiError('Invalid credentials', 403);

    const match = await bcrypt.compare(password, admin.password);
    if (!match) throw new ApiError('Invalid credentials', 403);

    // Generate JWT token
    const token = jwt.sign({ id: admin._id, email: admin.email }, ACCESS_TOKEN_SECRET, {
      expiresIn: '2d',
    });
      // Exclude the password before sending the response
      const adminData = admin.toObject();
      delete adminData.password;

    // If the password matches, return success
    return res.status(200).json({
      success: true,
      token,
      user: adminData,
      message: 'Login successfully'
    });
  } catch (error) {
    console.log('error',error)
    next(error);
  }
};

module.exports = login;
