const multer = require('multer');
const fs = require('fs');
const { Admin } = require("../../../models")
const { ApiError } = require('../../../errorHandler');
const { deleteOldFile } = require('../../../utils');
const allowedMimeTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
const jwt = require('jsonwebtoken');
const { ACCESS_TOKEN_SECRET } = process.env;


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    if (!fs.existsSync('public/admin')) {
      fs.mkdirSync('public/admin', { recursive: true });
    }
    cb(null, 'public/admin');
  },
  filename: function (req, file, cb) {
    const { originalname } = file;
    let fileExt = '.jpeg';
    const extI = originalname.lastIndexOf('.');
    if (extI !== -1) {
      fileExt = originalname.substring(extI).toLowerCase();
    }
    const fileName = `admin-${Date.now()}${fileExt}`;
    cb(null, fileName);
  },
});
const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    allowedMimeTypes.includes(file.mimetype) ? cb(null, true) : cb(new ApiError('Invalid image type', 400));
  },
}).single('profile_image');

const updateProfile = async (req, res, next) => {
  upload(req, res, async (error) => {
    try {
      if (error) throw new ApiError(error.message, 400);
      
      const adminId = req.admin._id;

      
      let { name,email  } = req.body;

      const admin = await Admin.findById(adminId).select('-password');

      if (!admin) {
        return res.status(404).json({
          success: false,
          message: 'Admin not found'
        });
      }

      if (email) {
        const existingAdmin = await Admin.findOne({ email, _id: { $ne: adminId } });
        if (existingAdmin) {
          throw new ApiError('Email is already in use by another account', 400);
        }
        admin.email = email;
      }


      if (name) admin.name = name;
      if (req.file) {
        await deleteOldFile(admin.profile_image);
        admin.profile_image = req.file.path;
        console.log(req.file);
      }

      await admin.save();

      const token = jwt.sign({ id: admin._id, email: admin.email }, ACCESS_TOKEN_SECRET, {
        expiresIn: '2d',
      });

      return res.status(200).json({
        success: true,
        message: 'Profile updated successfully',
        user: admin,
        token
      });
    } catch (error) {
      if (req.file) deleteOldFile(req.file.path);
      next(error);
    }
  });
};

module.exports = updateProfile;
