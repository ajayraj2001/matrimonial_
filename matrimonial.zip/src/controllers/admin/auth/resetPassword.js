const { ApiError } = require('../../../errorHandler');
const { Admin } = require('../../../models');
const bcrypt = require('bcrypt');

const resetPassword = async (req, res, next) => {
  try {
    const { email, newPassword } = req.body;

    // Validate input
    if (!email || !newPassword) throw new ApiError('Email and new password are required', 400);

    // Find the admin by email
    const admin = await Admin.findOne({ email });
    if (!admin) throw new ApiError('Admin not found', 404);

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update the admin's password
    admin.password = hashedPassword;
    admin.otp = null; // Clear the OTP after successful password reset
    admin.otp_expiry = null;
    await admin.save();

    // Return success response
    return res.status(200).json({
      success: true,
      message: 'Password has been reset successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = resetPassword;
