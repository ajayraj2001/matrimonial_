const { getFileUploader } = require('../../../middlewares/fileUpload');


const { Dhyaan } = require('../../../models');
const { deleteOldFile } = require('../../../utils');

const uploadPoster = getFileUploader('dhyanPoster', 'uploads/dhyaans', ['image/png', 'image/jpeg', 'image/jpg', 'image/webp']);

const createDhyaan = async (req, res, next) => {
  try {
    // Upload the poster image
    uploadPoster(req, res, async function (err) {
      if (err) return next(err);

      const { dhyanName, dhyanDescription, dhyanContent, isActive, priority } = req.body;

      const existingDhyaan = await Dhyaan.findOne({ dhyanName: dhyanName.trim() });
      if (existingDhyaan) {
        return res.status(400).json({
          success: false,
          message: `The dhyaan name "${dhyanName}" already exists.`,
        });
      }

      // Validate priority if it is provided
      if (priority) {
        const priorityNumber = parseInt(priority, 10);
        
        if (isNaN(priorityNumber) || priorityNumber < 1 || priorityNumber > 10) {
          return res.status(400).json({
            success: false,
            message: "Priority must be a number between 1 and 10.",
          });
        }

        // Check if the priority is already assigned to another book
        const existingPriority = await Dhyaan.findOne({ priority: priorityNumber });
        if (existingPriority) {
          return res.status(400).json({
            success: false,
            message: `The priority "${priorityNumber}" is already assigned to the dhyaan "${existingPriority.dhyanName}".`,
          });
        }
      }

      const dhyaan = new Dhyaan({
        dhyanName,
        dhyanDescription,
        dhyanPoster: req.file ? req.file.path : null,
        dhyanContent,
        isActive,
        priority: priority ? parseInt(priority, 10) : null,
      });

      await dhyaan.save();
      return res.status(201).json({
        success: true,
        message: 'Dhyaan created successfully',
        data: { dhyaan },
      });
    });
  } catch (error) {
    // If an error occurs, delete the uploaded file if it exists
    if (req.file && req.file.path) {
      deleteOldFile(req.file.path);
    }
    next(error);
  }
};

module.exports = createDhyaan;
