const { Dhyaan } = require('../../../models');
const { deleteOldFile } = require('../../../utils');

const deleteDhyaan = async (req, res, next) => {
  try {
    const dhyaan = await Dhyaan.findByIdAndDelete(req.params.id);
    if (!dhyaan) return res.status(404).json({ success: false, message: 'Dhyaan not found' });

    await deleteOldFile(dhyaan.dhyanPoster); // Delete the poster image

    return res.status(200).json({
      success: true,
      message: 'Dhyaan deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = deleteDhyaan;
