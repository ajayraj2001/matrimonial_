const { Dhyaan } = require('../../../models');
const { getFileUploader } = require('../../../middlewares/fileUpload');
const {deleteOldFile} = require('../../../utils');

const uploadPoster = getFileUploader('dhyanPoster', 'uploads/dhyaans', ['image/png', 'image/jpeg', 'image/jpg', 'image/webp']);

const updateDhyaan = async (req, res, next) => {
  try {
    uploadPoster(req, res, async function (err) {
      if (err) return next(err);


      const dhyaan = await Dhyaan.findById(req.params.id);
      if (!dhyaan) return res.status(404).json({ success: false, message: 'Dhyaan not found' });

      const { dhyanName, dhyanDescription, dhyanContent, isActive, priority } = req.body;

      const isActiveBool = isActive === 'true';


      if (dhyanName) {
        const existingDhyanName = await Dhyaan.findOne({
          dhyanName,
          _id: { $ne: req.params.id }, // Exclude the current book
        });
        if (existingDhyanName) {
          return res.status(400).json({
            success: false,
            message: `The dhyaan name '${dhyanName}' already exists in another document.`,
          });
        }
      }

      // Check if the priority already exists in another document
      if (priority) {
        const existingPriority = await Dhyaan.findOne({
          priority,
          _id: { $ne: req.params.id }, // Exclude the current book
        });
        if (existingPriority) {
          return res.status(400).json({
            success: false,
            message: `The priority '${priority}' already exists in another dhyaan named '${existingPriority.dhyanName}'.`,
          });
        }
      }



      if (req.file && dhyaan.dhyanPoster) {
        deleteOldFile(dhyaan.dhyanPoster); // Delete old poster image if a new one is uploaded
      }

      dhyaan.dhyanName = dhyanName || dhyaan.dhyanName;
      dhyaan.dhyanDescription = dhyanDescription || dhyaan.dhyanDescription;
      dhyaan.dhyanPoster = req.file ? req.file.path : dhyaan.dhyanPoster;
      dhyaan.dhyanContent = dhyanContent || dhyaan.dhyanContent;
      dhyaan.priority = priority || dhyaan.priority;
      dhyaan.isActive = isActive !== undefined ? isActiveBool : dhyaan.isActive;

      await dhyaan.save();
      return res.status(200).json({
        success: true,
        message: 'Dhyaan updated successfully',
        data: { dhyaan },
      });
    });
  } catch (error) {
    if (req.file && req.file.path) {
      deleteOldFile(req.file.path);
    }
    next(error);
  }
};

module.exports = updateDhyaan;
