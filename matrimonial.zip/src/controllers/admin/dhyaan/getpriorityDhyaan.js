const { Dhyaan } = require('../../../models');

// Get books with priority (up to 10)
const getPriorityDhyaan = async (req, res, next) => {
  try {
    const priorityDhyaan = await Dhyaan.find({ priority: { $ne: null } })
      .sort({ priority: 1 }) // Sort by priority in ascending order (1-10)
      .limit(10); // Limit the result to 10 books

    return res.status(200).json({
      success: true,
      message: 'Priority dhyaans retrieved successfully',
      books: priorityDhyaan,
    });
  } catch (error) {
    next(error);
  }
};

module.exports =  getPriorityDhyaan 
