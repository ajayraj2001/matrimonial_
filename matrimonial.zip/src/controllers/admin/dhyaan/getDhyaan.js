const { Dhyaan } = require('../../../models');

const getDhyaanById = async (req, res, next) => {
  try {
    const dhyaan = await Dhyaan.findById(req.params.id);
    if (!dhyaan) return res.status(404).json({ success: false, message: 'Dhyaan not found' });

    return res.status(200).json({
      success: true,
      message: 'Dhyaan retrieved successfully',
      data: { dhyaan },
    });
  } catch (error) {
    next(error);
  }
};

//get all dhyaans
const getAllDhyaans = async (req, res, next) => {
  try {
    const { page, limit, search } = req.query;

    // Convert page and limit to integers and set default values
    const pageNumber = parseInt(page, 10) || 1;
    const pageSize = parseInt(limit, 10) || 10;

    // Create a search query object
    let searchQuery = {};
    if (search) {
      // Perform a case-insensitive search for dhyanName
      searchQuery.dhyanName = new RegExp(search, 'i');
    }

    // Count the total number of documents based on the search query
    const total_data = await Dhyaan.countDocuments(searchQuery);

    // Calculate the total number of pages
    const total_pages = Math.ceil(total_data / pageSize);

    // Apply pagination and search query
    const dhyaans = await Dhyaan.find(searchQuery)
      .sort({ _id: -1 })
      .skip((pageNumber - 1) * pageSize)
      .limit(pageSize);

    return res.status(200).json({
      success: true,
      message: 'Dhyaans retrieved successfully',
      dhyaans,
      pagination: {
        total_data,
        total_pages,
        current_page: pageNumber,
        page_size: pageSize,
      },
    });
  } catch (error) {
    next(error);
  }
};

 
module.exports = { getDhyaanById, getAllDhyaans};
