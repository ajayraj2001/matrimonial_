const { ApiError } = require("../../../errorHandler");
const {Tag} = require("../../../models")

const getTags = async (req, res, next) => {
  try {
      let page = req.query.page ? Number(req.query.page) : null;
      let limit = req.query.limit ? Number(req.query.limit) : null;
      let skip = 0;

      if (page && limit) {
          skip = (page - 1) * limit;
      }

      console.log('page', page)
      console.log('page qw  qw  q', limit)
      const total_data = await Tag.countDocuments();
      const total_page = limit ? Math.ceil(total_data / limit) : 1;

      const tags = await Tag.find().skip(skip).limit(limit ? limit : 0).lean();
      return res.status(200).json({
          success: true,
          message: "Tags list",
          data: {
              tags,
              page: page || 1,
              limit: limit || total_data,
              total_page,
              total_data,
          }
      });
  } catch (error) {
      next(error);
  }
};



  

  module.exports = getTags