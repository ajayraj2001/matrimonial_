const { ApiError } = require("../../../errorHandler");
const { Tag } = require("../../../models")
const { isValidObjectId } = require('mongoose')

const updateTag = async (req, res, next) => {
    try {
        const { id } = req.params;

        if (!isValidObjectId(id)) {
            throw new ApiError("Invalid Id", 400);
        }

        const { name ,hindiName} = req.body;
        if (!name) {
            throw new ApiError(400, 'Tag name is required');
        }
        const tag = await Tag.findByIdAndUpdate(id, { name ,hindiName}, { new: true });
        if (!tag) {
            throw new ApiError(404, 'Tag not found');
        }
        return res.status(200).json({
            success: true,
            message: "Tag updated successfully",
            data: {
                tag
            },
        });
    } catch (error) {
        next(error);
    }
};

module.exports = updateTag