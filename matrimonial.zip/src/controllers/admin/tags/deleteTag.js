const { ApiError } = require("../../../errorHandler");
const {Tag} = require("../../../models")
const {isValidObjectId} = require('mongoose')

const deleteTag = async (req, res, next) => {
    try {
      const { id } = req.params;

        if (!isValidObjectId(id)) {
            throw new ApiError("Invalid Id", 400);
        }

      const tag = await Tag.findByIdAndDelete(id);
      if (!tag) {
        throw new ApiError(404, 'Tag not found');
      }
      return res.status(200).json({
        success: true,
        message: "Tag removed successfully",
    });
    } catch (error) {
      next(error);
    }
  };

  module.exports = deleteTag