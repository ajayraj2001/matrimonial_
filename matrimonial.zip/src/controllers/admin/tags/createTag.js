const { ApiError } = require("../../../errorHandler");
const {Tag} = require("../../../models")

const createTag = async (req, res, next) => {
    try {
      let { name ,hindiName} = req.body;
      if (!name) {
        throw new ApiError(400, 'Tag name is required');
      }

      name = name.charAt(0).toUpperCase() + name.slice(1);
 
      const exist = await Tag.findOne({name})
      if(exist) {
        return res.status(400).json({
          success: false,
          message: "Tag already exists",
      });
    }
      
      const tag = new Tag({ name,hindiName });
      await tag.save();
      return res.status(201).json({
        success: true,
        message: "Tag created",
        data: tag,
    });
    } catch (error) {
      next(error);
    }
  };

  module.exports = createTag