const { Book, User, Dhyaan } = require('../../../models');

const userDashboard = async (req, res, next) => {
    try {
        const userId = req.user._id;

        // Find user excluding password
        const user = await User.findById(userId).select('-password');

        const books = await Book.find()
            .sort({ clicks: -1, _id: -1 })
            .limit(8);


        const dhyaans = await Dhyaan.find()
            .sort({ clicks: -1, _id: -1 })
            .limit(8);


        return res.status(200).json({
            success: true,
            message: 'User Dashboard',
            user,
            books,
            dhyaans,
        });
    } catch (error) {
        next(error);
    }
};

module.exports = userDashboard;
