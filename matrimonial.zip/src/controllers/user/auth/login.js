const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { ApiError } = require('../../../errorHandler');
const { User } = require('../../../models');
const { ACCESS_TOKEN_SECRET } = process.env; // Assuming you have your secret stored in an environment variable

const login = async (req, res, next) => {
  try {
    let { phone, email, loginType } = req.body;

    if (!loginType) throw new ApiError('Login type is required.', 400);

    if (loginType === 'phone') {
      if (!phone) throw new ApiError('Phone is required.', 400);

      // Find the user by phone
      const user = await User.findOne({ phone , active: true});
      if (!user) throw new ApiError('User not found with this phone.', 403);

      // Generate JWT token
      const token = jwt.sign({ id: user._id }, ACCESS_TOKEN_SECRET, {
        expiresIn: '2d',
      });

      return res.status(200).json({
        success: true,
        message: `An OTP has been successfully sent to the mobile ****${user.phone.slice(-4)}.`,
        token,
      });
    } else if (loginType === 'social') {
      if (!email) throw new ApiError('Email is required for social login.', 400);

      // Find the user by email
      const user = await User.findOne({ email });
      if (!user) throw new ApiError('User not found with this email.', 403);

      // Generate JWT token
      const token = jwt.sign({ id: user._id }, ACCESS_TOKEN_SECRET, {
        expiresIn: '2d',
      });

      return res.status(200).json({
        success: true,
        message: 'Login successful.',
        token,
      });
    } else {
      throw new ApiError('Invalid login type.', 400);
    }
  } catch (error) {
    next(error);
  }
};


module.exports = login;
