const { ApiError } = require('../../../errorHandler');
const { User } = require('../../../models');
const bcrypt = require('bcrypt');

const resetPassword = async (req, res, next) => {
  try {
    const { email, newPassword } = req.body;

    // Validate input
    if (!email || !newPassword) throw new ApiError('Email and new password are required', 400);

    // Find the admin by email
    const user = await User.findOne({ email });
    if (!user) throw new ApiError('Admin not found', 404);

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update the admin's password
    user.password = hashedPassword;
    user.otp = null; // Clear the OTP after successful password reset
    user.otp_expiry = null;
    await user.save();

    // Return success response
    return res.status(200).json({
      success: true,
      message: 'Password has been reset successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = resetPassword;
