const bcrypt = require('bcrypt');
const { ApiError } = require('../../../errorHandler');
const { User } = require('../../../models');
const { getOtp } = require('../../../utils');

const signup = async (req, res, next) => {
  try {
    let { email, fullName, phone, profile_for, _id } = req.body;

    // Validate required fields
    if (!email) return next(new ApiError('Email is required.', 400));
    if (!phone) return next(new ApiError('Phone is required.', 400));
    if (!fullName) return next(new ApiError('Full Name is required.', 400));
    if (!profile_for) return next(new ApiError('Profile for is required.', 400));

    // Trim inputs
    email = String(email).trim();

    // Validate phone number format
    if (phone && (isNaN(phone) || phone.includes('e') || phone.includes('.') || phone.length !== 10)) {
      return next(new ApiError('Invalid phone number format.', 400));
    }

    // Check if the user exists by phone number
    let existingUser = await User.findOne({ phone: phone });

    // If the user exists but hasn't verified OTP, check the email as well
    if (existingUser && !existingUser.active) {
      const emailInUseByAnotherUser = await User.findOne({ email: email, _id: { $ne: existingUser._id } });

      if (emailInUseByAnotherUser) {
        return next(new ApiError('This email is already in use by another user.', 400));
      }

      // Resend OTP if the email is not in use by another user
      const otp = getOtp();
      const otpExpiry = new Date(Date.now() + 2 * 60 * 1000);

      existingUser.profile_for= profile_for;
      existingUser.fullName= fullName;
      existingUser.otp = otp;
      existingUser.otp_expiry = otpExpiry;

      await existingUser.save();

      // Resend OTP
      // sendOtp(existingUser.phone, otp);

      return res.status(200).json({
        success: true,
        message: `An OTP has been successfully sent to ****${existingUser.phone.slice(-4)}.`,
      });
    }

    // Check if the email is already in use by another user (exclude the current user by _id)
    existingUser = await User.findOne({ email: email });
    if (existingUser && (!existingUser._id.equals(_id))) {
      return next(new ApiError('User is already registered with this email.', 400));
    }

    // If the user doesn't exist, create a new user
    if (!existingUser) {
      const newUser = new User({
        email,
        fullName: fullName.trim(),
        phone,
        active: false,
      });

      // Generate OTP and set expiry
      const otp = getOtp();
      const otpExpiry = new Date(Date.now() + 2 * 60 * 1000);

      newUser.otp = otp;
      newUser.otp_expiry = otpExpiry;

      // Save the new user to the database
      await newUser.save();

      // Send OTP to user's phone
      // sendOtp(newUser.phone, otp);

      return res.status(201).json({
        success: true,
        message: `An OTP has been sent to the mobile ****${newUser.phone.slice(-4)}.`,
      });
    }

    // If we reach here, it means the email belongs to the current user, but other fields need to be updated
    // Update other fields as needed
    existingUser.fullName = fullName.trim();
    existingUser.phone = phone;

    // Generate new OTP and set expiry
    const otp = getOtp();
    const otpExpiry = new Date(Date.now() + 2 * 60 * 1000);

    existingUser.otp = otp;
    existingUser.otp_expiry = otpExpiry;

    // Save the updated user to the database
    await existingUser.save();

    // Resend OTP
    // sendOtp(existingUser.phone, otp);

    return res.status(200).json({
      success: true,
      message: `An OTP has been sent to the mobile ****${existingUser.phone.slice(-4)}.`,
    });
  } catch (error) {
    next(error);
  }
};


module.exports = signup;
