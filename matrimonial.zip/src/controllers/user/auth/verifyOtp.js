const { ApiError } = require('../../../errorHandler');
const { User } = require('../../../models');
const { STATIC_OTP,  ACCESS_TOKEN_SECRET} = process.env;

const verifyOtpSignUp = async (req, res, next) => {
  try {
    const { phone, otp } = req.body;

    console.log('otp',STATIC_OTP)

    // Validate input
    if (!phone || !otp) throw new ApiError('Phone and OTP are required', 400);

    // Find the admin by phone or email
    const user = await User.findOne({ phone:phone});
    if (!user) throw new ApiError('User not found', 404);

    // Validate OTP
    if (Date.now() > new Date(user.otp_expiry).getTime()) throw new ApiError('OTP expired', 400);
    if (user.otp !== otp && otp !== STATIC_OTP ) throw new ApiError('Invalid OTP', 400);

    user.active = true

    user.save()

    // If OTP is valid, return success response
    return res.status(200).json({
      success: true,
      message: 'OTP verified successfully',
    });
  } catch (error) {
    next(error);
  }
};

const verifyOtpLogin = async (req, res, next) => {
  try {
    const { phone, otp } = req.body;

    // Validate input
    if (!phone || !otp) throw new ApiError('Phone and OTP are required', 400);

    // Find the admin by phone or email
    const user = await User.findOne({ phone:phone});
    if (!user) throw new ApiError('User not found', 404);

    // Validate OTP
    if (Date.now() > new Date(user.otp_expiry).getTime()) throw new ApiError('OTP expired', 400);
    if (user.otp !== otp && otp !== STATIC_OTP ) throw new ApiError('Invalid OTP', 400);

    user.active = true

    user.save()

    const token = jwt.sign({ id: user._id, phone: user.phone }, ACCESS_TOKEN_SECRET);

    return res.status(200).json({
      status: true,
      message: 'Login Successfully.',
      data: {
        token,
        user,
      },
    });

  } catch (error) {
    next(error);
  }
};

module.exports = {verifyOtpSignUp, verifyOtpLogin};
