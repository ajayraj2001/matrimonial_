const { ApiError } = require('../../../errorHandler');

const logout = async (req, res, next) => {
  try {
    console.log('user',req.user)
    req.user.otp = null;
    req.user.otp_expiry = null;

    await req.user.save();

    return res.status(200).json({
      success: true,
      message: 'Logged out successfully.',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = logout;
