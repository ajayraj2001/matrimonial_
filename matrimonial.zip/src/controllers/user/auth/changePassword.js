const { ApiError } = require('../../../errorHandler');
const { User } = require('../../../models');
const bcrypt = require('bcrypt');

const changePassword = async (req, res, next) => {
  try {
    const {oldPassword, newPassword } = req.body;
    const userId = req.user._id

    // Validate input
    if (!oldPassword || !newPassword) {
      throw new ApiError('Old password, and new password are required', 400);
    }

    // Find the admin by email
    const user = await User.findById(userId );
    if (!admin) {
      throw new ApiError('Admin not found', 404);
    }

    // Compare oldPassword with the current password
    const isMatch = await bcrypt.compare(oldPassword, admin.password);
    if (!isMatch) {
      throw new ApiError('Old password is incorrect', 401);
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update the admin's password
    admin.password = hashedPassword;
    await admin.save();

    // Return success response
    return res.status(200).json({
      success: true,
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.log('error',error)
    next(error);
  }
};

module.exports = changePassword;
