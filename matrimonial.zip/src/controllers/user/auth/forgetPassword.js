const { ApiError } = require('../../../errorHandler');
const { User } = require('../../../models');
const { getOtp } = require('../../../utils');
const  sendOtpEmail  = require('../../../utils/sendOtpToEmail'); // Assuming you have a function to send SMS as well

const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) throw new ApiError('Email is required', 400);

    // Find the user by either phone or email
    const user = await User.findOne({
     email: email
    });

    if (!user) throw new ApiError('User not found with this email', 404);

    const otp = getOtp();
    const otpExpiry = new Date(Date.now() + 2 * 60 * 1000);

    // Save the OTP and its expiry time
    user.otp = otp;
    user.otp_expiry = otpExpiry;
    await user.save();

    await sendOtpEmail(user.email, otp);


    return res.status(200).json({
      success: true,
      message: `OTP has been sent to your registered email address ${user.email}`,
      data: {
        email: user.email,
        otpExpiry: user.otp_expiry,
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = forgotPassword;
